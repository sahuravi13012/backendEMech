import React from "react";
// import "antd/dist/antd.css";
import Data from "./Card_data";
import Chart from "./Chart";

function Dashboard() {
  return (
    <>
      <div className="container mt-2">
        <div className="row">
          <div className="col">
            <div className="row">
              {Data.map((value) => {
                return (
                  <div className="col-lg-3 col-md-6 bg-light">
                    <div className="inner_part">
                      <div className="card">
                        <img
                          src={value.image}
                          class="card-img-top"
                          alt="..."
                          height="110px"
                        ></img>
                        <div className="card-body">
                          <h5 class="card-title">{value.tittle}</h5>
                          <p class="card-text">{value.description}</p>
                          <a href="#" class="btn btn-primary">
                            {value.btn}
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          {/* <div className="row bg-dark">
            <div className="conatiner">
              <div className="col-4">
               
              </div>
            </div>
          </div> */}
        </div>
        <div className="row p-3">
          <div className="col-xl-6 col-md-12 ">
            <Chart />
          </div>
          <div className="col-xl-6 col-md-12 ">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit.
            Voluptates, magnam?
          </div>
        </div>
      </div>
    </>
  );
}

export default Dashboard;
