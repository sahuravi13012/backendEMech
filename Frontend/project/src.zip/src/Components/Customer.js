import React from "react";

function Customer() {
  return <div>Customer</div>;
}

export default Customer;
