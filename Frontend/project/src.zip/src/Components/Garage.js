import React from "react";

function Garage() {
  return <div>Garage</div>;
}

export default Garage;
