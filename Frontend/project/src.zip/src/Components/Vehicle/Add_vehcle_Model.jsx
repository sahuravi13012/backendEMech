import React from "react";

function Add_vehcle_Model() {
  return <div>Add_vehcle_Model</div>;
}

export default Add_vehcle_Model;
