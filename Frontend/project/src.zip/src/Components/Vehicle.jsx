import React from "react";

export default function Vehicle() {
  return <div>Vehicle</div>;
}
