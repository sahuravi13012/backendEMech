import React, { useState } from "react";
import "./Sidebar.css";
import { ArrowLeftOutlined, ArrowRightOutlined } from "@ant-design/icons";
import Sidebardata from "../Components/Sidebar_data";
import { NavLink } from "react-router-dom";
<ArrowRightOutlined />;
<ArrowLeftOutlined />;

function Sidebar({ children }) {
  const [openmenu, setOpenMenu] = useState(false);
  const toggle = () => setOpenMenu(!openmenu);
  return (
    <>
      <div className="container-fluid">
        <div className="sidebar" style={{ width: openmenu ? "250px" : "60px" }}>
          <div className="top-section">
            <h1
              className="logo"
              style={{ display: openmenu ? "block" : "none" }}
            >
              Logo
            </h1>
            <div
              className="menu"
              style={{ marginLeft: openmenu ? "100px" : "0px" }}
            >
              {openmenu ? (
                <ArrowLeftOutlined onClick={toggle} />
              ) : (
                <ArrowRightOutlined onClick={toggle} />
              )}
            </div>
          </div>
          {Sidebardata &&
            Sidebardata.map((value, index) => {
              return (
                <NavLink
                  to={`${value.path}`}
                  key={index}
                  className="link"
                  activelassName="active"
                >
                  <div className="icon">{value.icon}</div>
                  <div
                    className="link-text"
                    style={{ display: openmenu ? "block" : "none" }}
                  >
                    {value.Name}
                  </div>
                </NavLink>
              );
            })}
        </div>

        <main>
          <div className="container-fluid bg-dark">
            <div className="row">
              <div className="col">fccktciryeyeyytttmdjy header</div>
            </div>
            <div className="row">
              <div className="col"> {children}</div>
            </div>
            <div className="row">
              <div className="col"> footer</div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
}

export default Sidebar;
