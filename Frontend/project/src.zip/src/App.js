import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Dashboard from "./Components/Dashboard";

import Garage from "./Components/Garage";
import Vehicle from "./Components/Vehicle";
import Customer from "./Components/Customer";
import Product from "./Components/Product";
import Sidebarsecond from "./Components/Sidebarsecond";
import Add_Vehicle_Category from "./Components/Vehicle/Add_Vehicle_Category";
import Add_Vehicle_company from "./Components/Vehicle/Add_Vehicle_company";
import Add_vehcle_Model from "./Components/Vehicle/Add_vehcle_Model";
import View_Vehicle_Category from "./Components/Vehicle/View_Vehicle_Category";
import View_Vehicle_Company from "./Components/Vehicle/View_Vehicle_Company";
import View_Vehicle_Model from "./Components/Vehicle/View_Vehicle_Model";
import Update_Vehicle_Category from "./Components/Vehicle/Update_vehicle_category";

function App() {
  return (
    <>
      <BrowserRouter>
        <Sidebarsecond>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            {/*- ----------Routes of vehicle Category----------------------- */}
            <Route
              path="/addvehiclecategory"
              element={<Add_Vehicle_Category />}
            />
            <Route
              path="/viewvehiclecategory"
              element={<View_Vehicle_Category />}
            />
            <Route
              path="/updatevehiclecategory/:vehicle_cat_id"
              element={<Update_Vehicle_Category />}
            />
            <Route
              path="/addvehiclecompany"
              element={<Add_Vehicle_company />}
            />
            <Route
              path="/viewvehiclecategory"
              element={<View_Vehicle_Company />}
            />
            <Route path="/addvehiclemodel" element={<Add_vehcle_Model />} />
            <Route
              path="/viewvehiclmodel"
              element={<View_Vehicle_Model />}
            />
          </Routes>
        </Sidebarsecond>
      </BrowserRouter>
    </>
  );
}

export default App;
